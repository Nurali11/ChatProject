"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateUserDto = void 0;
var CreateUserDto = /** @class */ (function () {
    function CreateUserDto() {
    }
    return CreateUserDto;
}());
exports.CreateUserDto = CreateUserDto;
