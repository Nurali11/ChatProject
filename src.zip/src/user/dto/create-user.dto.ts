export class CreateUserDto {
    name: string
    userName: string
    phone: string
    photo? :string
}
