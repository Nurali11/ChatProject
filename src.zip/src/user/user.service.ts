import { Injectable } from '@nestjs/common';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { PrismaService } from 'src/prisma/prisma.service';

@Injectable()
export class UserService {
  constructor(
    private readonly prisma: PrismaService
  ) {}
  async create(data: CreateUserDto) {
    try {
      let user = await this.prisma.user.create({ data })
      return user
    } catch (error) {
      return error.message
    }
  }

  async findAll() {
    try {
      let users = await this.prisma.user.findMany()
      return users
    } catch (error) {
      return error.message
    }
  }

  async findOne(id: string) {
    try {
      let user = await this.prisma.user.findFirst({where: {id: id}})
    } catch (error) {
      return error.message
    }
  }

  update(id: string, updateUserDto: UpdateUserDto) {
    try {
      
    } catch (error) {
      return error.message
    }
  }

  remove(id: string) {
    try {
      
    } catch (error) {
      return error.message
    }
  }
}
