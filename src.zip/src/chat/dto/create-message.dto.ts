export class CreateMessageDto {
    fromId: string
    toId: string
    chatId: string
    text: string
}
