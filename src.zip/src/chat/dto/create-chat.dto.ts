export class CreateChatDto {
    fromId: string
    toId: string
}
