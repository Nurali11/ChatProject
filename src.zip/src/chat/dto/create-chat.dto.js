"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateChatDto = void 0;
var CreateChatDto = /** @class */ (function () {
    function CreateChatDto() {
    }
    return CreateChatDto;
}());
exports.CreateChatDto = CreateChatDto;
