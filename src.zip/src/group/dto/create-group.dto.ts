export class CreateGroupDto {
    groupName: string
    name: string
}
